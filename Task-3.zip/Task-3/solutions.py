# Task 3: Python Coding & Problem-Solving

# Q1) 
def word_frequency(sentence):
    frequency = {}
    for word in sentence.split():
        frequency[word] = frequency.get(word, 0) + 1
    return frequency


# Q2)
def character_frequency(word):
    frequency = {}
    for char in word:
        frequency[char] = frequency.get(char, 0) + 1
    return frequency


# Q3)
def first_non_repeating_character(word):
    frequency = character_frequency(word)
    for char in word:
        if frequency[char] == 1:
            return char
    return None


# Q4)
def are_anagrams(s1, s2):
    return character_frequency(s1) == character_frequency(s2)


# Q5)
def first_repeating_character(text):
    seen = set()
    for char in text:
        if char in seen:
            return char
        seen.add(char)
    return None


# Q6)
def move_zeros_to_end(nums):
    non_zeros = [num for num in nums if num != 0]
    zeros = [num for num in nums if num == 0]
    return non_zeros + zeros


# Q7)
def second_highest_distinct(nums):
    unique_nums = sorted(set(nums), reverse=True)
    if len(unique_nums) < 2:
        return None
    return unique_nums[1]


# Q8)
def remove_duplicates(nums):
    result = []
    seen = set()
    for num in nums:
        if num not in seen:
            result.append(num)
            seen.add(num)
    return result


# Q9)
def find_missing_number(nums, n):
    expected_sum = n * (n + 1) // 2
    return expected_sum - sum(nums)


# Q10)
def find_pair_sum(nums, target):
    seen = []
    for current in nums:
        needed = target - current
        for previous in seen:
            if previous == needed:
                return [previous, current]
        seen.append(current)
    return []


# Q11)
def closest_to_zero(nums):
    if not nums:
        return None
    return min(nums, key=lambda number: (abs(number), -number))


# Q12)
def common_elements(list1, list2):
    set2 = set(list2)
    result = []
    seen = set()
    for item in list1:
        if item in set2 and item not in seen:
            result.append(item)
            seen.add(item)
    return result


# Q13)
def rotate_right(nums, k):
    if not nums:
        return []
    k = k % len(nums)
    if k == 0:
        return nums.copy()
    return nums[-k:] + nums[:-k]


# Q14)
def max_consecutive_pair_sum(nums):
    return max(nums[i] + nums[i + 1] for i in range(len(nums) - 1))


# Q15)
def all_unique_pairs_sum(nums, target):
    pairs = set()
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                pairs.add(tuple(sorted((nums[i], nums[j]))))
    return [list(pair) for pair in sorted(pairs)]
