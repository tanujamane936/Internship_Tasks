## 2.Arithmetic Operators
## https://www.hackerrank.com/challenges/python-arithmetic-operators/problem
a = int(input())
b = int(input())
print(a + b)
print(a - b)
print(a * b)