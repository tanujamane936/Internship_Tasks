# Select ALL
# https://www.hackerrank.com/challenges/select-all-sql/problem
SELECT * FROM CITY;