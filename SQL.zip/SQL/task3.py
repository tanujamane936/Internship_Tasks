# SELECT * FROM CITY;
# https://www.hackerrank.com/challenges/japanese-cities-attributes/problem
SELECT * FROM CITY WHERE COUNTRYCODE = 'JPN';